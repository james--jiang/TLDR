# TL;DR

Version: 1.0 | October 2015


<b>What is TL;DR?</b> <br/>
    Similar to the common ackronym, tl;dr (too long; didn't read). It is a Google Chrome extension, developed at Cal Hacks 2015, that simplifies articles on webpages into short summaries. 
    
    
<b>How can you use it?</b> <br/>  
        
    
    
<b>How is it done? </b> <br/>
    1. Parses the article into words and sentences. <br/>
    2. Assigns "popularity" points to each occurance of a word. <br/>
    3. Sentence "popularity" is then formed from the sum of those words' values. <br/>
    4. Return a certain percanatage of the most highly ranked sentences in chronological order. <br/>


<b>Who are we? </b> <br/>
    We are a group of UC Berkeley students who have really short attention spans but enjoy trying to force ourselfs to read long articles because we are dirty masochists. 
    
    
<b>TL;DR? </b> <font style="background-color: yellow;">Highlight text and click extention for summaries!</font>
